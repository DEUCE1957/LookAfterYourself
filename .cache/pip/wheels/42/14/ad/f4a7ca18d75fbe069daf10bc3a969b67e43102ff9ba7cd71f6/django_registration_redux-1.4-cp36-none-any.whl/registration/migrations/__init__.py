"""
Django migrations for django-registration-redux

This package does not contain South migrations.

These are Django native migrations. They require Django > 1.7.

"""
